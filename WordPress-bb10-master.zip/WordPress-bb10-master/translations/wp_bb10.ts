<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>BlogsSelectionDialog</name>
    <message>
        <source>Done</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CustomDialogCategories</name>
    <message>
        <source>Done</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>blogslist</name>
    <message>
        <source>None selected</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>commentslist</name>
    <message>
        <source>DELETE COMMENT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure to delete this comment?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>editcomment</name>
    <message>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Author e-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Author url</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Waiting for approve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Spam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Comment</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>editpost</name>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Public</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Private</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aside</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quote</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Post</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <source>Change blog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Posts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>makePost</name>
    <message>
        <source>Creating the new post, please wait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Picture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Post</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Post Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Post Content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Public</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Private</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aside</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quote</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>pageslist</name>
    <message>
        <source>DELETE PAGE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure to delete this page?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>postslist</name>
    <message>
        <source>Deleting post, please wait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DELETE POST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
