WordPress-bb10
==============

WordPress mobile app for BlackBerry 10 devices.

GSoC 2013 project

Requirements:
=============

* BlackBerry Native SDK 
* simulator

(you can find both here : https://developer.blackberry.com/native/download/)

Build&Run:
==========

1. Launch the Native SDK
2. On the File Menu, click Import
3. Expand General, and select Existing Projects into Workspace. Click Next.
4. Browse to the location where you clone the repo and click OK. 
5. Click Finish to import the project into your workspace.
6. Click Project Menu, and select Build Project.
7. Click Run menu, select Run.
8. Enjoy

